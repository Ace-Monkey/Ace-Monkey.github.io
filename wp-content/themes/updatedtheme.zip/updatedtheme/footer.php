</main>
</div>
 <footer>
<div class="footerLogo">
	<a href="/"><img src="" alt="logo"/></a>
	 </div>
	 <div class="footerContent">
	 <div class="fBox">
	<h4>Find us</h4>
		 <p>
			 15-17 Blackfriars Lane<br>London<br>EC4V 6ER
		 </p>
	 </div>
	 <div class="fBox">
	<h4>Call us</h4>
		 <p>
			 +44 (0)20 7489 7666
		 </p>
	 </div>
	 <div class="fBox">
	<h4>Email us</h4>
		 <p>
			 General enquiries<br><a href="mailto:info@modulestudios.co.uk">info@modulestudios.co.uk</a>
		 </p>
		 <p>
			 Work with us<br><a href="mailto:joinus@modulestudio.co.uk">joinus@modulestudio.co.uk</a>
		 </p>
	 </div>
	 <div class="fBox">
	<h4>Follow us</h4>
 		<img src="" width="25" height="25"/>
 		<img src="" width="25" height="25"/>
 		<img src="" width="25" height="25"/>
 		<img src="" width="25" height="25"/>
	 </div>
</div>
</footer>
<?php wp_footer(); ?> <!-- This is the place where it puts every function i create -->
<script>
//put scripts that use php here!
</script>
 </body>
</html>