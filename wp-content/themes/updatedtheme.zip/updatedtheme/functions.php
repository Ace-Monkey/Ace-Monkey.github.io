<?php 

function custom_script_get() {
	//wp_enqueue_style('customstyle', get_template_directory_uri() . 'stles.css', array(),'1.0.0','all'); DOSENT WORK - USING HEADER ONE!
	wp_enqueue_script('customjs', get_template_directory_uri() . '/js/scripts.js', array(), '1.0.0', true);
	wp_enqueue_script( 'togglemenujs', get_template_directory_uri() . '/js/navigation.js', array('jquery'), '1.0.0', true );
}

add_action('wp_enqueue_scripts', 'custom_script_get');

function custom_theme_setup() {
	
	add_theme_support('menus');
	add_theme_support( 'post-thumbnails' );
	$headerDefaults = array(
	'flex-height'            => true,
	'flex-width'             => true,
	'width'                  => 45,
	'height'                 => auto,
	'uploads'                => true,
	'random-default'         => false,
	'header-text'            => true,
);
	add_theme_support( 'custom-header', $headerDefaults );
	add_post_type_support( 'page', 'excerpt' );
	
	register_nav_menu('main', 'Main Header Navigation');
	register_nav_menu('secondery', 'Secondery Extra Navigation');
}

// function u_widgets_init() {
//     register_sidebar( array(
//         'name'          => __( 'Social Links', 'helios' ),
// 		'description'   => __( 'The widget that controls the social links in the footer and the menu.' ),
//         'id'            => 'social-1',
//     ) );
 
//     register_sidebar( array(
//         'name'          => __( 'Secondary Sidebar', 'helios' ),
//         'id'            => 'sidebar-2',
//         'before_widget' => '<ul><li id="%1$s" class="widget %2$s">',
//         'after_widget'  => '</li></ul>',
//         'before_title'  => '<h3 class="widget-title">',
//         'after_title'   => '</h3>',
//     ) );
// }

add_action( 'widgets_init', 'u_widgets_init' );

function my_custom_upload_mimes($mimes = array()) {

	$mimes['csv'] = "text/html";
	$mimes['svg'] = 'image/svg+xml';
	return $mimes;
}

add_action('upload_mimes', 'my_custom_upload_mimes');
add_action('init', 'custom_theme_setup');
