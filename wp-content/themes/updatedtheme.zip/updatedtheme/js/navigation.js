jQuery(".toggle-menu").click(function() {
	jQuery(".menu-panel").toggleClass("slide");
	jQuery(".toggle-menu").toggleClass("close");
});
