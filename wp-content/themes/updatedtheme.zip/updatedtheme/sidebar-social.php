<div id="sidebar-social" class="sSocial">
    <?php dynamic_sidebar( 'social-1' ); ?>
</div>